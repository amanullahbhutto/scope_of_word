<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Tehsil extends Model
{
    use SoftDeletes;

    protected $fillable = [
        'tehsil_name', 'district_id',
    ];

    public function region()
    {
        return $this->belongsTo(Region::class);
    }
    
}
