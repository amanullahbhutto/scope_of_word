<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class CompanyInfo extends Model
{

    // Specify the table name
    protected $table = 'company_info';

    // Define the fillable properties for mass assignment
    protected $fillable = [
        'name_of_company', 
        'registered_address_province', 
        'registered_address_city', 
        'complete_address', 
        'business_name', 
        'addition_information', 
        'company_type', 
        'service', 
        'product', 
        'last_updated_date', 
        'source_of_this_information', 
        'source_provided_id', 
        'company_annual_revenue', 
        'company_annual_revenue_year', 
        'company_capital', 
        'no_of_employees', 
        'no_of_offices', 
        'head_office_city', 
        'date_of_establishment', 
        'international_presence', 
        'other_addresses', 
        'web_address', 
        'contact_person', 
        'telephone_no', 
        'email_address', 
        'reg_no', 
        'sector',
        'cell_no',
    ];

    // Specify if timestamps are not used
    public $timestamps = false;
}
