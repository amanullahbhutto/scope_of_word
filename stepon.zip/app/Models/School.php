<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class School extends Model
{
    // use SoftDeletes;
    protected $table = 'school_data';


    protected $fillable = [
        'school_id', 'school_name', 'region', 'district', 'tehsil', 'uc', 
        'school_address', 'latitude', 'longitude', 'costcenter', 'location',
        'gender', 'shift', 'level', 'status', 'closure_reason', 'closure_period',
        'building_availability', 'cunstruction_type', 'building_condition', 
        'rooms', 'classroom_total', 'ece_classrooms', 'primary_classrooms', 
        'post_primary_classrooms', 'drinking_water', 'electricity', 'toilet',
        'boundry_wall', 'medium', 'boys_enrolled', 'girls_enrolled', 
        'total_enrolled', 'male_teachers', 'female_teahers', 'total_teachers_staff'
    ];

    public function regions()
    {
        return $this->belongsTo(Region::class, 'region');
    }

    public function districts()
    {
        return $this->belongsTo(District::class, 'district');
    }

    
    public function Tehsils()
    {
        return $this->belongsTo(Tehsil::class, 'tehsil');
    }

 

    public function teachers()
    {
        return $this->hasMany(Teacher::class, 'school_id', 'school_id');
    }

    
}