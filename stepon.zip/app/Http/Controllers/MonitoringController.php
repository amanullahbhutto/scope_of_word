<?php

namespace App\Http\Controllers;

use App\Models\MonitoringRequest; // Adjust the model name if it's different
use Illuminate\Http\Request as HttpRequest;


class MonitoringController extends Controller
{
    /**
     * Display all the requests.
     *
     * @return \Illuminate\View\View
     */
    public function index()
    {
        // Retrieve all requests
        $requests = MonitoringRequest::all();

        return view('admin.monitrering.index', compact('requests'));
    }

    /**
     * Display pending requests.
     *
     * @return \Illuminate\View\View
     */
    public function pending()
    {
        // Retrieve only pending requests
        $requests = MonitoringRequest::where('status', 'pending')->get();

        return view('admin.monitrering.pending', compact('requests'));
    }

    /**
     * Display accepted requests.
     *
     * @return \Illuminate\View\View
     */
    public function accepted()
    {
        // Retrieve only accepted requests
        $requests = MonitoringRequest::where('status', 'accepted')->get();

        return view('admin.monitrering.approved', compact('requests'));
    }

    /**
     * Display rejected requests.
     *
     * @return \Illuminate\View\View
     */
    public function rejected()
    {
        // Retrieve only rejected requests
        $requests = MonitoringRequest::where('status', 'rejected')->get();

        return view('admin.monitrering.rejected', compact('requests'));
    }
}
