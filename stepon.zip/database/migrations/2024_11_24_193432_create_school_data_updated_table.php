<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('schools', function (Blueprint $table) {
            $table->id(); // Auto-incrementing primary key
            $table->integer('school_id')->nullable();
            $table->string('school_name', 255)->default(''); // Default to empty string
            $table->integer('region')->nullable(); // Nullable integer column
            $table->integer('district')->nullable();
            $table->integer('tehsil')->nullable();
            $table->string('uc', 255)->default('');
            $table->string('school_address', 255)->default('');
            $table->string('latitude', 255)->default('');
            $table->string('longitude', 255)->default('');
            $table->string('costcenter', 255)->default('');
            $table->string('location', 255)->default('');
            $table->string('gender', 255)->default('');
            $table->string('shift', 255)->default('');
            $table->string('level', 255)->default('');
            $table->string('status', 255)->default('');
            $table->string('closure_reason', 255)->default('');
            $table->string('closure_period', 255)->default('');
            $table->string('building_availability', 255)->default('');
            $table->string('cunstruction_type', 255)->default('');
            $table->string('building_condition', 255)->default('');
            $table->string('rooms', 255)->default('');
            $table->string('classroom_total', 255)->default('');
            $table->string('ece_classrooms', 255)->default('');
            $table->string('primary_classrooms', 255)->default('');
            $table->string('post_primary_classrooms', 255)->default('');
            $table->string('drinking_water', 255)->default('');
            $table->string('electricity', 255)->default('');
            $table->string('toilet', 255)->default('');
            $table->string('boundry_wall', 255)->default('');
            $table->string('medium', 255)->default('');
            $table->string('boys_enrolled', 255)->default('');
            $table->string('girls_enrolled', 255)->default('');
            $table->string('total_enrolled', 255)->default('');
            $table->string('male_teachers', 255)->default('');
            $table->string('female_teahers', 255)->default('');
            $table->string('total_teachers_staff', 255)->default('');
            $table->timestamps();
            $table->softDeletes(); 
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('schools');
    }
};
