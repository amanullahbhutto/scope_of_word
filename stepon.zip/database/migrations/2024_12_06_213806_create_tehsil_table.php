<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateTehsilTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('tehsil', function (Blueprint $table) {
            $table->increments('id'); // Auto-incrementing primary key
            $table->string('tehsil_name')->nullable(); // Nullable column for tehsil_name
            $table->integer('district_id')->nullable(); // Nullable column for district_id (foreign key reference)
            $table->timestamps(); // Created at and updated at columns
            $table->softDeletes(); // Soft delete column (deleted_at)
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('tehsil');
    }
}
