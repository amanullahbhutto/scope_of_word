<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateMonitoringRequestsTable extends Migration
{
    public function up()
    {
        Schema::create('monitoring_requests', function (Blueprint $table) {
            $table->id(); // Auto-incrementing primary key
            $table->string('full_name');
            $table->string('email');
            $table->string('phone');
            
            // Make sure these foreign keys use unsignedBigInteger
            $table->BigInteger('region_id');
            $table->BigInteger('district_id');
            $table->BigInteger('tehsil_id');
            
            $table->string('school_id');
            $table->string('otp')->nullable();
            $table->text('address');
            $table->enum('status', ['pending', 'approved', 'rejected'])->default('pending');
            $table->timestamps();

        });
    }

    public function down()
    {
        Schema::dropIfExists('monitoring_requests');
    }
}
