<?php 
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateTeachersTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('teachers', function (Blueprint $table) {
            $table->id(); // Primary key, auto-increment
            $table->string('teacher_name')->nullable(); // Teacher name
            $table->bigInteger('school_id')->nullable(); // School ID
            $table->bigInteger('teacher_id')->nullable(); // Teacher ID
            $table->string('gender', 255)->nullable(); // Gender
            $table->string('designation')->default(''); // Designation
            $table->timestamps(); // Adds created_at and updated_at columns
            $table->softDeletes(); // Adds deleted_at column for soft deletes
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('teachers');
    }
}
