<?php 
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateAdoptedSchoolsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('adopted_schools', function (Blueprint $table) {
            $table->id(); // Auto-incrementing primary key
            $table->unsignedBigInteger('school_id'); // Adding school_id to the table
            $table->string('meta_key'); // Meta key like 'school_id'
            $table->text('meta_value'); // Meta value, could be serialized data
            $table->timestamps(); // Created at and updated at timestamps

            // Optional: You can add a foreign key constraint if `school_id` references a `schools` table
            // $table->foreign('school_id')->references('id')->on('schools')->onDelete('cascade');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('adopted_schools');
    }
}
